const { mentionedJid } = require('@whiskeysockets/baileys');
const config = require('../config.json');

module.exports = {
  name: 'kick',
  description: 'Kick a user from the group.',
  category: 'group',
  async execute(sock, m, args, reply, store) {
    const groupMetadata = m.isGroup ? await sock.groupMetadata(m.chat) : {};
    const botNumber = sock.user.id.split(':')[0];
    const isBotAdmin = m.isGroup && groupMetadata.participants.some(p => p.id.includes(botNumber) && p.admin);
    const isUserAdmin = m.isGroup && groupMetadata.participants.some(p => p.id === m.sender && p.admin);
    const isPremium = config.premiumUsers.includes(m.senderNumber);

    // Not a group
    if (!m.isGroup) return reply(m, '`⛔𝘞𝘳𝘰𝘯𝘨 𝘳𝘦𝘢𝘭𝘮 𝘧𝘰𝘰𝘭... 𝘛𝘩𝘪𝘴 𝘴𝘱𝘦𝘭𝘭 𝘰𝘯𝘭𝘺 𝘸𝘰𝘳𝘬𝘴 𝘪𝘯 𝘨𝘳𝘰𝘶𝘱𝘴.`');

    // Bot not admin
    if (!isBotAdmin) return reply(m, '`⚠️𝘌𝘷𝘦𝘯 𝘴𝘩𝘢𝘥𝘰𝘸𝘴 𝘯𝘦𝘦𝘥 𝘱𝘦𝘳𝘮𝘪𝘴𝘴𝘪𝘰𝘯... 𝘔𝘢𝘬𝘦 𝘮𝘦 𝘢𝘯 𝘢𝘥𝘮𝘪𝘯 𝘵𝘰 𝘣𝘢𝘯𝘪𝘴𝘩 𝘴𝘰𝘶𝘭𝘴.`');

    // Not admin or premium
    if (!isUserAdmin && !isPremium && m.senderNumber !== botNumber)
      return reply(m, '`💀𝘞𝘩𝘰 𝘴𝘦𝘯𝘵 𝘵𝘩𝘪𝘴 𝘤𝘭𝘰𝘸𝘯?💀 𝘖𝘯𝘭𝘺 𝘴𝘩𝘢𝘥𝘰𝘸 𝘮𝘢𝘴𝘵𝘦𝘳𝘴 𝘤𝘢𝘯 𝘤𝘢𝘴𝘵 𝘵𝘩𝘦 𝘣𝘢𝘯𝘪𝘴𝘩 𝘳𝘪𝘵𝘶𝘢𝘭.`');

    let target;
    if (m.quoted) {
      target = m.quoted.sender;
    } else if (m.message.extendedTextMessage?.contextInfo?.mentionedJid?.length) {
      target = m.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }

    if (!target) return reply(m, '`🤡𝘠𝘰𝘶 𝘧𝘰𝘳𝘨𝘰𝘵 𝘵𝘰 𝘤𝘩𝘰𝘰𝘴𝘦 𝘢 𝘴𝘢𝘤𝘳𝘪𝘧𝘪𝘤𝘦... 𝘛𝘢𝘨 𝘰𝘳 𝘳𝘦𝘱𝘭𝘺 𝘵𝘰 𝘢 𝘵𝘢𝘳𝘨𝘦𝘵 𝘧𝘪𝘳𝘴𝘵.`');

    try {
      await sock.groupParticipantsUpdate(m.chat, [target], 'remove');
      reply(m, '`☠️𝘈 𝘴𝘩𝘢𝘥𝘰𝘸 𝘩𝘢𝘴 𝘧𝘢𝘥𝘦𝘥... 𝘛𝘩𝘦 𝘳𝘦𝘢𝘭𝘮 𝘪𝘴 𝘤𝘭𝘦𝘢𝘯𝘴𝘦𝘥.`');
    } catch (err) {
      console.error(err);
      reply(m, '`⚡𝘛𝘩𝘦 𝘳𝘪𝘵𝘶𝘢𝘭 𝘧𝘢𝘪𝘭𝘦𝘥... 𝘔𝘢𝘺𝘣𝘦 𝘵𝘩𝘢𝘵 𝘴𝘩𝘢𝘥𝘰𝘸 𝘪𝘴 𝘢𝘯 𝘢𝘥𝘮𝘪𝘯 𝘰𝘳 𝘢𝘭𝘳𝘦𝘢𝘥𝘺 𝘦𝘷𝘢𝘱𝘰𝘳𝘢𝘵𝘦𝘥.`');
    }
  }
};